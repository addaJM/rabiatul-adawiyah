<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
        // put your code here
        $servername = "localhost";
        $username = "root";
        $password ="";
        $database -"reg";
        
        $conn = new mysqli($servername, $username, $password, $database);
        
        if($conn->connect_error)
        {
                die("Connection failed: " . $conn->connect_error);
        }
        echo "Connected successfull!";
        
        
      